# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: light
#       format_version: '1.5'
#       jupytext_version: 1.13.1
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# # Random Forest model train

# + pycharm={"name": "#%%\n"}
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score
from sklearn.metrics import roc_auc_score, roc_curve

from mlflow.models import infer_signature
from urllib.parse import urlparse
from sklearn.ensemble import RandomForestClassifier
from matplotlib import pyplot
from sklearn.model_selection import GridSearchCV
import pandas as pd
from sklearn.model_selection import train_test_split
import logging
import mlflow
from urllib.parse import urlparse

import numpy as np
from sklearn.preprocessing import StandardScaler
import sys
import os
from mlflow.models import infer_signature
# Obtenez le chemin absolu du répertoire parent du notebook
notebook_directory = os.path.abspath('')
src_path = os.path.join(notebook_directory, '../../src/')

sys.path.insert(0, src_path)
import data.features.fem_data  as fem
# -

# ## Splitting dataset into train and test

# + pycharm={"name": "#%%\n"}


def get_split_train_data(file_path='../../data/final/train_data_final.pkl', test_size=0.3, validation_size=0.1, random_state=42):
    """Return a tuple containing split data into X_train, X_val, X_test, y_train, y_val, and y_test."""
    df = fem.read_pickle(file_path)
    target_df = fem.read_pickle('../../data/final/target_data_final.pkl')

    # Combine features and target variable
    df['TARGET'] = target_df

    # Separate features and target
    X = df.drop(['TARGET'], axis=1)
    y = df['TARGET']

    # Standardize features
    scaler = StandardScaler()
    X_std = scaler.fit_transform(X)

    # Replace NaN values with 0
    X_std[np.isnan(X_std)] = 0

    # Split data into training, validation, and test sets
    X_train, X_temp, y_train, y_temp = train_test_split(X_std, y, test_size=(test_size + validation_size), random_state=random_state)
    X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=test_size / (test_size + validation_size), random_state=random_state)
 
    return X_train, X_test, y_train, y_test



# -

# ## Adding MLFLow workflow

# ### Configuring logs

# + pycharm={"name": "#%%\n"}
def get_configured_logger():
  """Return a logger for console outputs configured to print warnings."""
  logging.basicConfig(level=logging.WARN)
  return logging.getLogger(__name__)


# -

# ### Training model on split data

# + pycharm={"name": "#%%\n"}
def train_random_forest_classifier(X_train, y_train):
  """Return RandomForestClassifier fit on input ndarrays X_train and y_train.

  Keyword arguments:
  X_train -- ndarray containing all train columns except target column
  y_train -- ndarray target column values to train the model
  """
  clf = RandomForestClassifier(class_weight = 'balanced_subsample', max_depth = 19,
                                       max_samples = 0.105493, min_samples_leaf = 26,
                                       min_samples_split = 44, n_estimators = 1403, n_jobs = -1,
                                       random_state = 210, verbose = 0)
  grid_search = GridSearchCV(clf, {'max_depth': [10, 15], 'min_samples_split': [5, 10]}, n_jobs=-1, cv=5, scoring='accuracy')
  grid_search.fit(X_train, y_train)
  clf.set_params(**grid_search.best_params_)
  clf = clf.fit(X_train, y_train)
  return clf


# -

# ### Getting model evaluation metrics

# + pycharm={"name": "#%%\n"}
def eval_metrics(actual, pred):
  """Return a tuple containing model classification accuracy, confusion matrix, f1_score and precision score.

  Keyword arguments:
  actual -- ndarray y_test containing true target values
  pred -- ndarray of the predicted target values by the model
  """
  accuracy = accuracy_score(actual, pred)
  conf_matrix = confusion_matrix(actual, pred)
  f_score = f1_score(actual, pred)
  precision = precision_score(actual, pred)
  return accuracy, conf_matrix, f_score, precision


# + pycharm={"name": "#%%\n"}
def get_model_evaluation_metrics(clf, X_test, y_test):
  """Return a tuple containing model classification accuracy, confusion matrix, f1_score, precision score and
  ROC area under the curve score.

  Keyword arguments:
  clf -- classifier model
  X_test -- ndarray containing all test columns except target column
  y_test -- ndarray target column values to test the model
  """
  predicted_repayments = clf.predict(X_test)
  (accuracy, conf_matrix, f_score, precision) = eval_metrics(y_test, predicted_repayments)
  rf_probs = clf.predict_proba(X_test)
  rf_probs = rf_probs[:, 0]  # keeping only the first class (repayment OK)
  rf_roc_auc_score = roc_auc_score(y_test, rf_probs)
  return accuracy, conf_matrix, f_score, precision, rf_roc_auc_score


# -

# ### Tracking model on MLFLow

# + pycharm={"name": "#%%\n"}
def track_model_params(clf):
  """Log model params on MLFlow UI.

  Keyword arguments:
  clf -- classifier model
  """
  clf_params = clf.get_params()
  for param in clf_params:
      param_value = clf_params[param]
      mlflow.log_param(param, param_value)
      
def set_mlflow_run_tags():
  """Set current MLFlow run tags."""
  tags = {'model_name': 'RandomForestClassifier'}
  mlflow.set_tags(tags)

# + pycharm={"name": "#%%\n"}
def track_model_metrics(clf, X_test, y_test):
  """Log model metrics on MLFlow UI.

  Keyword arguments:
  clf -- classifier model
  X_test -- ndarray containing all test columns except target column
  y_test -- ndarray target column values to test the model
  """
  (accuracy, conf_matrix, f_score, precision, rf_roc_auc_score) = get_model_evaluation_metrics(clf, X_test, y_test)
  mlflow.log_metric('accuracy', accuracy)
  mlflow.log_metric('f1_score', f_score)
  mlflow.log_metric('precision', precision)
  mlflow.log_metric('roc_auc_score', rf_roc_auc_score)
  tn, fp, fn, tp = conf_matrix.ravel()
  mlflow.log_metric('true_negatives', tn)
  mlflow.log_metric('false_positives', fp)
  mlflow.log_metric('false_negatives', fn)
  mlflow.log_metric('true_positives', tp)


# + pycharm={"name": "#%%\n"}
def track_model_version(clf):
  """Version model on MLFlow UI.

  Keyword arguments:
  clf -- classifier model
  """
  mlflow.sklearn.log_model(clf, 'model', registered_model_name='RandomForestClassifier')
 


# + pycharm={"name": "#%%\n"}
def train_and_track_model_in_mlflow():
  """Train model and track it with MLFLow"""
  (X_train, X_test, y_train, y_test) = get_split_train_data()
  logger = get_configured_logger()
  clf = train_random_forest_classifier(X_train, y_train)
  with mlflow.start_run():
    track_model_params(clf)
    track_model_metrics(clf, X_test, y_test)
    #track_model_version(clf)
    set_mlflow_run_tags()
    signature = infer_signature(X_train, clf.predict(X_train))

    # Log the model
    model_info = mlflow.sklearn.log_model(
        sk_model=clf,
        artifact_path="model",
        signature=signature,
        #input_example=X_train,
        registered_model_name="RandomForestClassifier",
    )


# + pycharm={"name": "#%%\n"}
if __name__ == '__main__':
    train_and_track_model_in_mlflow()
