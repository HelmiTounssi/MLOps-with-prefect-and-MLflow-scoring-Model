        
#importing Useful DataStructures
import pandas as pd
import numpy as np
from scipy.stats import uniform

#importing plotting libraries
import matplotlib.pyplot as plt
import seaborn as sns
from prettytable import PrettyTable

#importing Misc Libraries
import os
import gc
import pickle
import warnings
warnings.filterwarnings('ignore')
from datetime import datetime

#for 100% jupyter notebook cell width
from IPython.core.display import display, HTML
display(HTML("<style>.container { width:100% !important; }</style>"))

#sklearn
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import RandomizedSearchCV
from sklearn.metrics import roc_auc_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import roc_curve
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import SGDClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.calibration import CalibratedClassifierCV

#other modelling libraries
from bayes_opt import BayesianOptimization
import xgboost as xgb
from xgboost import XGBClassifier
from xgboost import XGBRegressor

import lightgbm as lgb
from lightgbm import LGBMClassifier
from lightgbm import LGBMRegressor
import sys
import os
#importing Useful DataStructures
import pandas as pd
import numpy as np
from scipy.stats import uniform
import mlflow
#importing plotting libraries
import matplotlib.pyplot as plt
import seaborn as sns
from prettytable import PrettyTable
from mlflow.models import infer_signature
#importing Misc Libraries
import os
import gc
import pickle
import warnings
warnings.filterwarnings('ignore')
from datetime import datetime
from sklearn.metrics import f1_score
#for 100% jupyter notebook cell width
from IPython.core.display import display, HTML
display(HTML("<style>.container { width:100% !important; }</style>"))
mlflow.set_tracking_uri(uri="http://127.0.0.1:5000")

#sklearn
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import RandomizedSearchCV
from sklearn.metrics import roc_auc_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_curve
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import SGDClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.calibration import CalibratedClassifierCV

#other modelling libraries
from bayes_opt import BayesianOptimization
import xgboost as xgb
from xgboost import XGBClassifier
from xgboost import XGBRegressor

import lightgbm as lgb
from lightgbm import LGBMClassifier
from lightgbm import LGBMRegressor
# Obtenez le chemin absolu du répertoire parent du notebook
notebook_directory = os.path.abspath('')
src_path = os.path.join(notebook_directory, '../../../src/')

sys.path.insert(0, src_path)

# Maintenant, vous pouvez importer votre module
import data.features.fem_data  as fem
import models.train.Modelling  as mod

import data.preprocess.Preprocess_bureau_balance_and_bureau  as Pre_bureau_balance
import data.preprocess.preprocess_installments_payments  as prep_inst_pay
import data.preprocess.preprocess_credit_card_balance  as prep_credit_card_bal
import data.preprocess.preprocess_POS_CASH_balance  as prep_POS_CASH_bal
import data.preprocess.preprocess_previous_application  as prep_previous_app
import data.features.recursive_feature_selector  as recursive_feature_selector
import data.preprocess.preprocess_application_train_test  as prep_app_train_test



class Boosting:
    '''
    Class for Boosting Ensembles and displaying results. Contains 6 methods:
    
        1. init method
        2. train method
        3. proba_to_class method
        4. tune_threshold method
        5. results method
        6. feat_importance_show
    '''

    def __init__(self, name_model, x_train, y_train, x_test, params, num_folds = 2, random_state = 33, verbose = True, save_model_to_pickle = False):
        '''
        Function to initialize the class members.
        
        Inputs:
            self
            x_train: DataFrame
                Training DataFrame
            y_train: DataFrame
                Training Class labels
            x_test: DataFrame
                Test DataFrame
            params: dict
                Parameters for the boosting ensemble
            num_folds: int, default = 3
                Number of folds for k-Fold Cross Validation
            random_state: int, default = 33
                Random State for Splitting the data for K-Fold Cross Validation
            verbose: bool, default = True
                Whether to keep verbosity or not
            save_model_to_pickle: bool, default = False
                Whether to save the model to pickle file or not
        
        Returns:
            None
        '''
        self.name_model = name_model
        self.x_train = x_train
        self.y_train = y_train
        self.x_test = x_test
        self.params = params
        self.num_folds = num_folds
        self.stratified_cv = StratifiedKFold(n_splits = num_folds, shuffle = True, random_state = random_state)
        self.verbose = verbose
        self.save_model = save_model_to_pickle
        self.best_model = None
        mlflow.set_experiment(f"{self.name_model}")
        
    def train(self, booster, verbose = 400, early_stopping = 200, pickle_name = ''):
        '''
        Function to train the Classifier on given parameters. It fits the classifier for each fold, and for Cross Validation,
        uses Out-of-Fold Predictions. The test predictions are averaged predictions over each fold.
        
        Inputs:
            self
            booster: str
                Whether the booster is 'xgboost' or 'lightgbm'
            verbose: int, default = 400
                Number of boosting rounds for printint boosting results.
            early_stopping: int, default = 200
                Number of boosting rounds to look for early stopping
            pickle_name: str, default = ''
                The string to add to end of pickle file of model, if any
        
        Returns:
            None        
        '''
        
        self.train_preds_proba_mean = np.zeros(self.x_train.shape[0])
        #out-of-fold cv predictions
        self.cv_preds_proba = np.zeros(self.x_train.shape[0])
        self.test_preds_proba_mean = np.zeros(self.x_test.shape[0])
        #best threshold will be 
        self.best_threshold_train = 0
        self.feature_importance = pd.DataFrame()
        self.feature_importance['features'] = self.x_train.columns
        self.feature_importance['gain'] = np.zeros(self.x_train.shape[1])
        
        if self.verbose:
            print(f"Fitting the {booster} on Training Data with {self.num_folds} fold cross validation, and using Out-Of-Folds Predictions for Cross-Validation")
            start = datetime.now()
        
        for fold_number, (train_indices, cv_indices) in enumerate(self.stratified_cv.split(self.x_train, self.y_train), 1):
            if self.verbose:
                print(f"\n\tFold Number {fold_number}\n")
            
            x_tr = self.x_train.iloc[train_indices]
            y_tr = self.y_train.iloc[train_indices]
            x_cv = self.x_train.iloc[cv_indices]
            y_cv = self.y_train.iloc[cv_indices]
            
            if booster == 'xgboost':
                clf = XGBClassifier(**self.params)
            else:
                clf = LGBMClassifier(**self.params)
                
            clf.fit(x_tr, y_tr, eval_set = [(x_tr, y_tr), (x_cv, y_cv)], eval_metric = 'auc',
                     verbose = verbose, early_stopping_rounds = 100)
            
            if booster == 'xgboost':
                self.train_preds_proba_mean[train_indices] = clf.predict_proba(x_tr, ntree_limit = clf.get_booster().best_ntree_limit)[:, 1] / (self.num_folds - 1)
                self.cv_preds_proba[cv_indices] = clf.predict_proba(x_cv, ntree_limit = clf.get_booster().best_ntree_limit)[:,1]
                self.test_preds_proba_mean += clf.predict_proba(self.x_test, ntree_limit = clf.get_booster().best_ntree_limit)[:,1] / self.num_folds

                #feature importance
                gain_fold = clf.get_booster().get_score(importance_type = 'gain')
                feat_imp = pd.DataFrame()
                feat_imp['features'] = gain_fold.keys()
                feat_imp['gain'] = gain_fold.values()
            
            else:
                self.train_preds_proba_mean[train_indices] = clf.predict_proba(x_tr, num_iteration = clf.best_iteration_)[:,1] / (self.num_folds - 1)
                self.cv_preds_proba[cv_indices] = clf.predict_proba(x_cv, num_iteration = clf.best_iteration_)[:,1]
                self.test_preds_proba_mean += clf.predict_proba(self.x_test, num_iteration = clf.best_iteration_)[:,1] / self.num_folds

                #feature importance
                gain_fold = clf.booster_.feature_importance(importance_type='gain')
                feat_imp = pd.DataFrame()
                feat_imp['features'] = self.x_train.columns
                feat_imp['gain'] = gain_fold
            
            #tuning the threshold for optimal TPR and FPR from ROC Curve
            self.best_threshold_train += self.tune_threshold(self.y_train[train_indices], self.train_preds_proba_mean[train_indices]) / self.num_folds
            #concatenating the feature importance of each fold to original df
            self.feature_importance = pd.concat([self.feature_importance, feat_imp], axis = 0)

            if self.save_model:
                #saving the model into a pickle file
                with open(f'clf_{booster}_fold_{fold_number}_model_{pickle_name}.pkl', 'wb') as f:
                    pickle.dump(clf, f)
        self.best_model = clf
        #mean feature importance averaged over all folds
        self.feature_importance = self.feature_importance.groupby('features', as_index = False).mean()
        #sorting the feature importance
        self.feature_importance = self.feature_importance.sort_values(by = 'gain', ascending = False)
        
        if self.verbose:
            print("Done.")
            print(f"Time elapsed = {datetime.now() - start}")
        gc.collect()
        
    def proba_to_class(self, proba, threshold):
        '''
        Function to convert a given probability to class label based on a threshold value.
        
        Inputs:
            self
            proba: numpy array
                Probabilities of class label = 1
            threshold: int
                Threshold probability to be considered as Positive or Negative Class Label
            
        Returns:
            Converted Class Label
        '''

        return np.where(proba >= threshold, 1, 0)
        
    def tune_threshold(self, true_labels, predicted_probas):
        '''
        Function to find the optimal threshold for maximizing the TPR and minimizing the FPR from ROC-AUC Curve.
        This is found out by using the J Statistic, which is J = TPR - FPR.
        Reference: https://machinelearningmastery.com/threshold-moving-for-imbalanced-classification/
        
        Inputs:
            self
            true_labels: numpy array or pandas series
                True Class Labels
            predicted_probas: numpy array
                Predicted Probability of Positive Class label
            
        Returns:
            Threshold probability.
        '''

        fpr, tpr, threshold = roc_curve(true_labels, predicted_probas)
        j_stat = tpr - fpr
        index_for_best_threshold = np.argmax(j_stat)
        
        return threshold[index_for_best_threshold]
           
    def results(self):
        '''
        Function to display the final results of Train, CV and Test Dataset.
        
        Inputs:
            self
        
        Returns:
            None
        '''
        
        #getting the crisp class labels
        with mlflow.start_run():
            self.train_preds_class = self.proba_to_class(self.train_preds_proba_mean, self.best_threshold_train)
            self.cv_preds_class = self.proba_to_class(self.cv_preds_proba, self.best_threshold_train)
            self.test_preds_class = self.proba_to_class(self.test_preds_proba_mean, self.best_threshold_train)
            clf_params = self.best_model.get_params()
            for param in clf_params:
                param_value = clf_params[param]
                mlflow.log_param(param, param_value)      
            print("=" * 100)
            print("Train Results:")
            print(f"\nThe best selected Threshold as per the J-Statistic, which is J = TPR - FPR, is = {self.best_threshold_train}\n")
            roc_auc_score_=roc_auc_score(self.y_train, self.train_preds_class)
            print(f"\tROC-AUC Score = {roc_auc_score(self.y_train, self.train_preds_class)}")
            precision_= precision_score(self.y_train, self.train_preds_class)
            recall_ = recall_score(self.y_train, self.train_preds_class)
            print(f"\tPrecision Score = {precision_score(self.y_train, self.train_preds_class)}")
            print(f"\tRecall Score = {recall_score(self.y_train, self.train_preds_class)}")
            f1_score_ = f1_score(self.y_train, self.train_preds_class)
            accuracy_score_value  = accuracy_score(self.y_train, self.train_preds_class)
            print(f"\accuracy Score = {accuracy_score_value }")
            print('=' * 100)
            print("Confusion, Precision and Recall Matrix on CV data:")
            conf_mat_ = confusion_matrix(self.y_train, self.train_preds_class)
            conf_mat = pd.DataFrame(conf_mat_, columns=['Predicted_0', 'Predicted_1'], index=['Actual_0', 'Actual_1'])

            # Création du graphique de la matrice de confusion
            plt.figure(figsize=(7, 6))
            plt.title('Confusion Matrix Heatmap')
            sns.heatmap(conf_mat, annot=True, fmt='g', linewidth=0.5, annot_kws={'size': 15})
            plt.savefig("Confusion.png")  # Enregistrer le graphique sous forme d'image
            plt.close()  # Fermer la figure pour libérer la mémoire

            # Enregistrer l'image de la matrice de confusion en tant qu'artefact MLflow
            mlflow.log_artifact("Confusion.png")
            random_probs = [0 for _ in range(len(self.y_train))]
             # Calculate ROC curves
            random_fpr, random_tpr, _ = roc_curve(self.y_train, random_probs)
            gb_fpr, gb_tpr, _ = roc_curve(self.y_train, self.train_preds_class)
            
            random_roc_auc_score = roc_auc_score(self.y_train, random_probs)
            # Create a new figure explicitly
            fig, ax = plt.subplots()
            # Summarize scores
            print('Random model: ROC AUC=%.3f' % random_roc_auc_score)
            print(' Booster: ROC AUC=%.3f' % roc_auc_score_)
            # Plot the ROC curve for the model
            ax.plot(random_fpr, random_tpr, linestyle='--', label='Random model')
            ax.plot(gb_fpr, gb_tpr, marker='.', label='Booster')

            # Axis labels
            ax.set_xlabel('False Positive Rate')
            ax.set_ylabel('True Positive Rate')
            plt.savefig("roc.png")
            plt.close(fig)
            # Show the legend
            ax.legend()
            mlflow.log_artifact("roc.png")    
            mlflow.log_metric('accuracy', accuracy_score_value )
            mlflow.log_metric('recall', recall_)
            mlflow.log_metric('f1_score', f1_score_)
            mlflow.log_metric('precision', precision_)
            mlflow.log_metric('roc_auc_score', roc_auc_score_)
            tn, fp, fn, tp = conf_mat_.ravel()
            mlflow.log_metric('true_negatives', tn)
            mlflow.log_metric('false_positives', fp)
            mlflow.log_metric('false_negatives', fn)
            mlflow.log_metric('true_positives', tp)
            """Set current MLFlow run tags."""
            tags = {'model_name': f"{self.name_model}"}
            mlflow.set_tags(tags)
            # Infer the model signature
            signature = infer_signature(self.x_train, self.x_test)

            # Log the model
            model_info = mlflow.sklearn.log_model(
            sk_model=self.best_model,
            artifact_path="model",
            signature=signature,
            #input_example=X_train,
             registered_model_name=f"{self.name_model}",  )
            
        
        gc.collect()
    
    def feat_importances_show(self, num_features, figsize = (10,15)):
        '''
        Function to display the top most important features.
        
        Inputs:
            self
            num_features: int
                Number of top features importances to display
            figsize: tuple, default = (10,15)
                Size of figure to be displayed
            
        Returns:
            None
        '''
  
        plt.figure(figsize=figsize) 
        sns.barplot(x=self.feature_importance['gain'].iloc[:num_features], 
        y=self.feature_importance['features'].iloc[:num_features], orient='h')
        plt.title(f'Top {num_features} features as per classifier')
        plt.xlabel('Feature Importance')
      
   
        plt.grid()
        plt.show()
        print('=' * 100)
        
        gc.collect()
        
    def  getModel(self):   
        return self.best_model