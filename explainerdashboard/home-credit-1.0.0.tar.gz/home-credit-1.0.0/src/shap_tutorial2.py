import pandas as pd
from explainerdashboard import ClassifierExplainer, ExplainerDashboard
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score
from sklearn.metrics import roc_auc_score, roc_curve
import logging

from urllib.parse import urlparse
from sklearn.ensemble import RandomForestClassifier
from matplotlib import pyplot
from sklearn.model_selection import GridSearchCV

import sys
import os
# Obtenez le chemin absolu du répertoire parent du notebook
notebook_directory = os.path.abspath('')
src_path = os.path.join(notebook_directory, '../../src/')

sys.path.insert(0, src_path)
import data.features.fem_data  as fem
import models.train.Modelling  as mod
import models.train.Boosting  as boost
# load a source module from a file

feature_descriptions = {
    "Sex": "Gender of passenger",
    "Gender": "Gender of passenger",
    "Deck": "The deck the passenger had their cabin on",
    "PassengerClass": "The class of the ticket: 1st, 2nd or 3rd class",
    "Fare": "The amount of money people paid", 
    "Embarked": "the port where the passenger boarded the Titanic. Either Southampton, Cherbourg or Queenstown",
    "Age": "Age of the passenger",
    "No_of_siblings_plus_spouses_on_board": "The sum of the number of siblings plus the number of spouses on board",
    "No_of_parents_plus_children_on_board" : "The sum of the number of parents plus the number of children on board",
}
train_data=pd.read_csv('../data/final/processed_application_features_importances_100.csv') 
df = fem.read_pickle('../data/final/train_data_final.pkl')
y_train = df['TARGET']
train_data = train_data.drop(['target'], axis=1)
train_data = train_data.drop(['prediction'], axis=1)
test_data = fem.read_pickle('../data/final/test_data_final.pkl')
# Convert the set to a list
columns_list = list(train_data.columns)
# Now use the list to select the columns from the DataFrame
df_selected = test_data[columns_list]
test_data=df_selected
params = {
        'objective' : 'binary',
        'boosting_type' : 'gbdt',
        'learning_rate' : 0.005,
        'n_estimators' : 10000,
        'n_jobs' : -1,
        'num_leaves' : 39,
        'max_depth' : 9,
        'min_split_gain' : 0.030820727751758883,
        'min_child_weight' : 30.074868967458226,
        'min_child_samples' : 31,
        'subsample': 0.7653763123038788,
        'subsample_freq' : 1,
        'colsample_bytree' : 0.6175714684701181,
        'reg_alpha' : 0.15663020002553255,
        'reg_lambda' : 0.22503178038757748,
        'verbosity' : -1,
        'seed' : 266
    }
lgbm_boosting = boost.Boosting('lightgbm_100',train_data, y_train, test_data, params, random_state = 98, save_model_to_pickle = True)
lgbm_boosting.train(booster = 'lightgbm_100')
model=lgbm_boosting.getModel()
train_data_first_100 = train_data.iloc[:100]
y_train_first_100=y_train.iloc[:100]
explainer = ClassifierExplainer(model, train_data_first_100, y_train_first_100, 
                                # adds a table and hover labels to dashboard
                                labels=['Not Paid', 'Paid'], # defaults to ['0', '1', etc]
                                target = "Not Paid", # defaults to y.name
                                )

db = ExplainerDashboard(explainer, 
                        title="Home Credit", # defaults to "Model Explainer"
                        shap_interaction=False, # you can switch off tabs with bools
                        )
db.run(port=8050)